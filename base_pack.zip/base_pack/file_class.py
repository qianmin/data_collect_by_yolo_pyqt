import os
import cv2
class yolo_file():
    def __init__(self,path):
        self.dir=path
    def show_dir(self):
        file_list=os.listdir(self.dir)
        for file in file_list:
            name=file[:-4]
            hz=file[-3:]
            print('文件名:',name,' 后缀:',hz)
    def get_max_name(self):
        # 获取目前最大文件名字
        max = 0
        file_list = os.listdir(self.dir)
        if len(file_list)!=0:
            for file in file_list:
                name = file[:-4]
                # print('name',name)
                if (max < int(name)):
                    max = int(name)
        else:
            print('空文件夹')
        print(max)
        return max

    def del_last_img(self):
        max=self.get_max_name()
        if max!=0:
            del_path=self.dir+str(max)+str('.jpg')
            print(del_path)
            os.remove(del_path)

    def if_have_path(self,path):
        #./data和./data/ 作用一样
        flag=os.path.exists(path)
        if flag:
            return True
        else:
            os.makedirs(path)
            return False


    def save_one_img(self,cv_img):
        self.if_have_path(self.dir)
        max=self.get_max_name()
        save_str=self.dir+str(max+1)+str('.jpg')
        print(max)
        print(save_str)
        cv2.imwrite(save_str,cv_img)
if __name__ == '__main__':
    my_file=yolo_file('./data/car/')
    test_img=cv2.imread('1.png',-1)
    # my_file.save_one_img(test_img)
    # my_file.del_last_img()
    my_file.del_last_img()