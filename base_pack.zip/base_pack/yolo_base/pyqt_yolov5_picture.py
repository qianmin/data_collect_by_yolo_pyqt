#! /usr/bin/env python3
import time
import cv2
import torch
from numpy import random
import torch.backends.cudnn as cudnn
import numpy as np
from models.experimental import attempt_load
from utils.general import (
    check_img_size, non_max_suppression, apply_classifier, scale_coords,
    xyxy2xywh, plot_one_box, strip_optimizer, set_logging)
from utils.torch_utils import select_device, load_classifier, time_synchronized

from matplotlib import pyplot as plt


class yolov5():
    def __init__(self):
        self.device=0
        self.model=0
        self.half=0
        self.weights=0
        self.imgsize=0

        self.load()
    def load(self):
        with torch.no_grad():
            # rospy.init_node('ros_yolo')
            # image_topic_1 = "/usb_cam/image_raw"
            # rospy.Subscriber(image_topic_1, Image, image_callback_1, queue_size=1, buff_size=52428800)
            # rospy.spin()
            '''
            '''
            set_logging()
            self.device = ''
            self.device = select_device(self.device)
            self.half = self.device.type != 'cpu'  # half precision only supported on CUDA
            self.weights = 'yolov5s.pt'
            self.imgsz = 640
            self.model = attempt_load(self.weights, map_location=self.device)  # load FP32 model
            imgsz = check_img_size(self.imgsz, s=self.model.stride.max())  # check img_size
            if self.half:
                self.model.half()  # to FP16

    def get_one_box(self,x, img):
        #去掉框
        n=5
        a = int(x[1])+n
        b = int(x[3])-n
        c = int(x[0])+n
        d = int(x[2])-n
        crop = img[a:b, c:d]
        return crop
    def letterbox(self,img, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True):
        # current shape [height, width]
        shape = img.shape[:2]  # current shape [height, width]
        if isinstance(new_shape, int):
            new_shape = (new_shape, new_shape)

        # Scale ratio (new / old)
        r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
        if not scaleup:  # only scale down, do not scale up (for better test mAP)
            r = min(r, 1.0)

        # Compute padding
        ratio = r, r  # width, height ratios
        new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
        dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
        if auto:  # minimum rectangle
            dw, dh = np.mod(dw, 32), np.mod(dh, 32)  # wh padding
        elif scaleFill:  # stretch
            dw, dh = 0.0, 0.0
            new_unpad = (new_shape[1], new_shape[0])
            ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

        dw /= 2  # divide padding into 2 sides
        dh /= 2

        if shape[::-1] != new_unpad:  # resize
            img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
        return img, ratio, (dw, dh)
    def loadimg(self,img):  # 接受opencv图片
        img_size=640
        cap=None
        path=None
        img0 = img
        img = self.letterbox(img0, new_shape=img_size)[0]
        img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR to RGB, to 3x416x416
        img = np.ascontiguousarray(img)
        return path, img, img0, cap
    def detect(self,img):
        cudnn.benchmark = True
        dataset = self.loadimg(img)
        plt.imshow(dataset[2][:, :, ::-1])
        names = self.model.module.names if hasattr(self.model, 'module') else self.model.names

        augment = 'store_true'
        conf_thres = 0.3
        iou_thres = 0.45
        # classes 0全部有   2car   3motor     0,1 行人  0,1,2人，车   0,1,2,5人，car，bus
        classes = (0)
        agnostic_nms = 'store_true'
        img = torch.zeros((1, 3, self.imgsz, self.imgsz), device=self.device)  # init img
        _ = self.model(img.half() if self.half else img) if self.device.type != 'cpu' else None  # run once
        path = dataset[0]
        img = dataset[1]
        im0s = dataset[2]
        img = torch.from_numpy(img).to(self.device)
        img = img.half() if self.half else img.float()  # uint8 to fp16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)
        # Inference
        pred = self.model(img, augment=augment)[0]
        # Apply NMS
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes=classes, agnostic=agnostic_nms)

        view_img = 1
        save_txt = 1
        save_conf = 'store_true'
        for i, det in enumerate(pred):  # detections per image
            p, s, im0 = path, '', im0s
            s += '%gx%g ' % img.shape[2:]  # print string
            gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
            if det is not None:
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()
                # Print results
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += '%g %ss, ' % (n, names[int(c)])  # add to string
                    # Write results
                for *xyxy, conf, cls in reversed(det):
                    if save_txt:  # Write to file
                        xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                        line = (cls, conf, *xywh) if save_conf else (cls, *xywh)  # label format
                    if view_img:  # Add bbox to image
                        label = '%s %.2f' % (names[int(cls)], conf)
                        plot_one_box(xyxy, im0, label=label, color=[0,255,0], line_thickness=3)
                    ####拿出检测结果
                    if xyxy is not None:
                        print(xyxy)
                        crop = self.get_one_box(xyxy, im0)
                        return im0,crop
                    else:
                        return im0,im0
            else:
                return im0,im0
            if 1:
                return im0

if __name__ == '__main__':
    ts=time.time()
    yolo=yolov5()
    cap = cv2.VideoCapture(0)
    img=cv2.imread('huge.jpg',-1)
    result_img=yolo.detect(img)
    cv2.imshow('result',result_img)
    cv2.waitKey(0)
    te=time.time()
    print("all_used_time",te-ts)
