import time
import cv2
from pyqt_yolov5_picture import yolov5

class out():
    def __init__(self):
        self.result=0
        self.model=yolov5()
    def out_detect(self,img):
        self.result=self.model.detect(img)
    def show(self):
        cv2.imshow('result',self.result)
        cv2.waitKey(0)
        
        
        
if __name__ == '__main__':
    img = cv2.imread('huge.jpg', -1)
    t=out()
    t.out_detect(img)
    t.show()
    
    # img=cv2.imread('huge.jpg',-1)
    # yolo=yolov5()
    # ts=time.time()
    # result=yolo.detect(img)
    # cv2.imshow('cnm',result)
    # cv2.waitKey(0)
    # te=time.time()
    # print("all_used_time",te-ts)

