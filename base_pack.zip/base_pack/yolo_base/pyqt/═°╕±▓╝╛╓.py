import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
class win(QWidget):
    def __init__(self,parent=None):
        super(win, self).__init__(parent)
        self.initUI()
    def initUI(self):
        self.setWindowTitle('网格布局')
        glayout = QGridLayout()
        btn1 = QPushButton('1', self)
        btn2 = QPushButton('2', self)
        glayout.addWidget(btn1, 1, 0)
        glayout.addWidget(btn2, 3, 1)
        self.setLayout(glayout)
        self.resize(600, 700)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = win()
    form.show()
    sys.exit(app.exec_())


