#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
import cv2

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import QPalette, QBrush, QPixmap
import cccccccccc


class Ui_MainWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(Ui_MainWindow, self).__init__(parent)

        # self.face_recong = face.Recognition()
        self.timer_camera = QtCore.QTimer()
        self.cap = cv2.VideoCapture()
        self.CAM_NUM = 0

        self.__flag_work = 0
        self.x = 0
        self.count = 0
        self.img=0


        self.set_ui()
        self.slot_init()
        # self.set_yolo()
    def set_ui(self): 
        #混合布局
        self.w_layput = QHBoxLayout()
        self.btn_layout = QVBoxLayout()
        self.img_layput = QHBoxLayout()

        # 初始化控件
        self.btn_open_cam = QPushButton(u'打开相机')
        self.btn_get_one = QPushButton(u'获得一帧图片')
        self.btn_detect=QPushButton(u'检测')
        self.btn_save=QPushButton(u'保存结果')
        self.btn_close =QPushButton(u'退出')

        self.label_source = QLabel()
        self.label_source.setFixedSize(640, 480)
        self.label_one_img=QLabel()
        self.label_one_img.setFixedSize(640,480)
        self.label_result = QLabel()
        self.label_result.setFixedSize(640, 480)


        # 初始化子布局
        self.btn_layout.addWidget(self.btn_open_cam)
        self.btn_layout.addWidget(self.btn_get_one)
        self.btn_layout.addWidget(self.btn_detect)
        self.btn_layout.addWidget(self.btn_save)
        self.btn_layout.addWidget(self.btn_close)

        self.img_layput.addWidget(self.label_source)
        self.img_layput.addWidget(self.label_one_img)
        self.img_layput.addWidget(self.label_result)


        self.w_layput.addLayout(self.btn_layout)
        self.w_layput.addLayout(self.img_layput)

        # 初始化全部布局
        self.setLayout(self.w_layput)
        self.setWindowTitle(u'摄像头')
    def slot_init(self):
        self.btn_open_cam.clicked.connect(self.button_open_camera_click)
        self.timer_camera.timeout.connect(self.show_camera)
        self.btn_close.clicked.connect(self.close)
        self.btn_get_one.clicked.connect(self.get_on_img)


    def button_open_camera_click(self):
        flag = self.cap.open(self.CAM_NUM)
        if flag == False:
            msg = QtWidgets.QMessageBox.warning(self, u"Warning", u"请检测相机与电脑是否连接正确",
                                                buttons=QtWidgets.QMessageBox.Ok,
                                                defaultButton=QtWidgets.QMessageBox.Ok)
        else:
            self.timer_camera.start(30)
            self.btn_open_cam.setText(u'关闭相机')
    def show_camera(self):
        flag, self.image = self.cap.read()
        show = cv2.resize(self.image, (640, 480))
        show = cv2.cvtColor(show, cv2.COLOR_BGR2RGB)
        showImage = QtGui.QImage(show.data, show.shape[1], show.shape[0], QtGui.QImage.Format_RGB888)
        self.label_source.setPixmap(QtGui.QPixmap.fromImage(showImage))

    def get_on_img(self):
        show = cv2.resize(self.image, (640, 480))
        show = cv2.cvtColor(show, cv2.COLOR_BGR2RGB)
        showImage = QtGui.QImage(show.data, show.shape[1], show.shape[0], QtGui.QImage.Format_RGB888)
        self.label_one_img.setPixmap(QtGui.QPixmap.fromImage(showImage))

    # def set_yolo(self):
    #

if __name__ == "__main__":
    App = QApplication(sys.argv)
    ex = Ui_MainWindow()
    ex.show()
    sys.exit(App.exec_())