import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
class win(QWidget):
    def __init__(self,parent=None):
        super(win, self).__init__(parent)

        self.setup_ui()
        self.setup_slot()

    def setup_ui(self):
        self.setWindowTitle('水平布局')
        self.input_layout=QVBoxLayout()

        self.label_input = QLabel()
        self.label_input.setText('输入保存文件夹')
        self.label_input.setFixedSize(300, 50)

        self.line_dir = QLineEdit()
        self.line_dir.setText('./data/people/')
        self.line_dir.setFixedSize(500, 50)

        self.label_num = QLabel()
        self.label_num.setText('输入文件名字（不要后缀）')
        self.label_num.setFixedSize(300, 50)

        self.line_name = QLineEdit()
        self.line_name.setText('cnm')
        self.line_name.setFixedSize(500, 50)

        self.btn_save = QPushButton(u'保存结果')
        self.btn_save.setMinimumSize(100, 100)


        self.input_layout.addWidget(self.label_input)
        self.input_layout.addWidget(self.line_dir)
        self.input_layout.addWidget(self.label_num)
        self.input_layout.addWidget(self.line_name)
        self.input_layout.addWidget(self.btn_save)



        self.setLayout(self.input_layout)
    def setup_slot(self):
        self.btn_save.clicked.connect(self.print_path)


    def print_path(self):
        str_folder = self.line_dir.text()
        str_name = self.line_name.text()
        save_path = str(str_folder + str_name + '.jpg')
        print(save_path)
if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = win()
    form.show()
    sys.exit(app.exec_())


