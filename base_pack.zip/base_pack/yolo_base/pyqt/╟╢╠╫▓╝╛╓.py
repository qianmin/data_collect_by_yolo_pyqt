import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
class win(QWidget):
    def __init__(self,parent=None):
        super(win, self).__init__(parent)
        self.initUI()
    def initUI(self):
        # 全局水平
        wlayout=QHBoxLayout()
        # 四个子布局
        hlayout=QHBoxLayout()
        vlayout=QVBoxLayout()
        glayout=QGridLayout()
        flayout=QFormLayout()

        # 子水平
        btn1 = QPushButton('1', self)
        btn2 = QPushButton('2', self)
        hlayout.addWidget(btn1)
        hlayout.addWidget(btn2)

        # 子垂直
        btn3 = QPushButton('3', self)
        btn4 = QPushButton('4', self)
        vlayout.addWidget(btn3)
        vlayout.addWidget(btn4)


        #合体
        hwg=QWidget()
        vwg=QWidget()
        gwg=QWidget()
        fwg=QWidget()

        hwg.setLayout(hlayout)
        vwg.setLayout(vlayout)

        wlayout.addWidget(hwg)
        wlayout.addWidget(vwg)

        self.setWindowTitle('四合一')
        self.setLayout(wlayout)
        self.resize(600, 700)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = win()
    form.show()
    sys.exit(app.exec_())


