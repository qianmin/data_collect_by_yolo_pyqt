# -*- coding: utf-8 -*-

'''
    【简介】
    PyQt5中QButton例子
'''

import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *

class Form(QDialog):
    def __init__(self, parent=None):
        super(Form, self).__init__(parent)
        layout = QVBoxLayout()   #设置垂直布局





        btn1=QPushButton('初始化',self)
        btn1.clicked.connect(self.f_init)
        layout.addWidget(self.btn1)

        btn2=QPushButton('截取一帧图片',self)
        btn2.clicked.connect(self.f_get_one_img)
        layout.addWidget(self.btn2)







        self.setWindowTitle("Button demo")

    def f_init(self):
        print("init")

    def f_get_one_img(self):
        print("get_one_img")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    btnDemo = Form()
    btnDemo.show()
    sys.exit(app.exec_())
