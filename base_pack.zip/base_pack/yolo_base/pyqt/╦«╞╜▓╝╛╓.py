import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
class win(QWidget):
    def __init__(self,parent=None):
        super(win, self).__init__(parent)
        self.setWindowTitle('水平布局')

        hlayout=QHBoxLayout()
        btn1=QPushButton('1',self)
        btn1.setMinimumSize(100,100)
        btn2=QPushButton('2',self)

        hlayout.addWidget(btn1)
        hlayout.addWidget(btn2)

        self.setLayout(hlayout)
        self.resize(600,700)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    form = win()
    form.show()
    sys.exit(app.exec_())


